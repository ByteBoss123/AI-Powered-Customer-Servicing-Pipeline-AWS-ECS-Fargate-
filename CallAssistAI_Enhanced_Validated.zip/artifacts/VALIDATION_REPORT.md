# CallAssist AI validation report

## Evaluation design

- Development benchmark: 40 fixed utterances x five acoustic conditions.
- Untouched holdout: 40 newly authored utterances x the same five conditions.
- Conditions: clean, faster speech, telephone band-limit, quiet speech, and pink noise.
- Speech recognition: OpenAI Whisper `tiny.en`; no transcript sidecars.
- The holdout was authored after the development vocabulary update and was not used for tuning.

## Development comparison

| Metric | Initial | Updated |
|---|---:|---:|
| Intent macro F1 | 64.2% | 78.1% |
| Policy Recall@1 | 73.0% | 78.0% |
| Policy Recall@3 | 90.0% | 94.5% |
| Escalation precision | 59.7% | 72.1% |
| Escalation recall | 100.0% | 100.0% |
| False-escalation rate | 45.0% | 25.8% |
| Mean WER | 14.0% | 13.6% |

## Untouched holdout results

| Metric | Result |
|---|---:|
| Audio cases | 200 |
| Unique utterances | 40 |
| Intent accuracy | 86.0% |
| Intent macro F1 | 76.9% |
| Policy Recall@1 / Recall@3 | 72.0% / 97.0% |
| Escalation precision / recall | 71.4% / 100.0% |
| False-escalation rate | 26.7% |
| Mean WER | 13.3% |
| Brier score / ECE | 0.106 / 0.324 |
| Mean / p95 end-to-end latency | 336 ms / 471 ms |

### Results by acoustic condition

| Condition | Macro F1 | Recall@3 | WER | P95 latency |
|---|---:|---:|---:|---:|
| clean | 77.5% | 97.5% | 11.1% | 497 ms |
| fast | 76.5% | 95.0% | 16.5% | 394 ms |
| pink_noise | 77.5% | 97.5% | 12.9% | 872 ms |
| quiet | 76.3% | 97.5% | 12.8% | 575 ms |
| telephone_band | 76.3% | 97.5% | 12.9% | 395 ms |

## Maintenance-control drill

- Detected 3 of 3 injected failure scenarios.
- Healthy-control false alarms: 0.
- Incidents persisted: 3.
- Promotion freeze: True.
- Rollback success: True to `maint-v1`.

## Claim boundaries

- All audio is synthetic; there are no real customers or external users.
- Latency was measured on a local CPU, not AWS.
- The remote benchmark and AWS deployment workflow are implemented but not executed without an AWS account.
- Escalation recall is high because fraud and identity changes are intentionally routed to human review.
- Calibration error and false escalations remain improvement opportunities.
