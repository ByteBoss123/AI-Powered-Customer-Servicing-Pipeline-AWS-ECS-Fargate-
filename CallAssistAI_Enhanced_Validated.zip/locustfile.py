from __future__ import annotations

import os

from locust import HttpUser, between, task


class CallAssistUser(HttpUser):
    wait_time = between(0.1, 0.8)

    @task(4)
    def payment_call(self) -> None:
        self.client.post(
            "/v1/calls/transcript",
            headers={"X-API-Key": os.getenv("CALLASSIST_API_KEY", "local-dev-key")},
            json={"transcript": "My payment of $125 is still pending and I need help."},
        )

    @task(1)
    def health(self) -> None:
        self.client.get("/health")

