from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from callassist.config import Settings
from callassist.evaluation import (
    binary_classification_metrics,
    brier_score,
    evaluate,
    expected_calibration_error,
    macro_f1,
)
from callassist.service import CallAssistService

ROOT = Path(__file__).resolve().parents[1]


class EvaluationTests(unittest.TestCase):
    def test_macro_f1(self) -> None:
        self.assertEqual(macro_f1(["a", "b"], ["a", "b"]), 1.0)

    def test_binary_metrics(self) -> None:
        metrics = binary_classification_metrics(
            [True, True, False, False], [True, False, True, False]
        )
        self.assertEqual(metrics["precision"], 0.5)
        self.assertEqual(metrics["recall"], 0.5)
        self.assertEqual(metrics["false_positive_rate"], 0.5)

    def test_calibration_metrics(self) -> None:
        self.assertAlmostEqual(brier_score([0.8, 0.2], [True, False]), 0.04)
        self.assertAlmostEqual(
            expected_calibration_error([0.8, 0.2], [True, False], bins=5), 0.2
        )

    def test_golden_dataset(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            service = CallAssistService(
                Settings(database_path=Path(directory) / "eval.db", policy_dir=ROOT / "data" / "policies")
            )
            metrics = evaluate(service, ROOT / "data" / "evaluation" / "calls.json")
        self.assertGreaterEqual(metrics["reason_macro_f1"], 0.80)
        self.assertGreaterEqual(metrics["escalation_recall"], 0.95)
        self.assertEqual(metrics["pii_leaks"], 0)


if __name__ == "__main__":
    unittest.main()
