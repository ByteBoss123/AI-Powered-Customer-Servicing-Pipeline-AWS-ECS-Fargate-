from __future__ import annotations

import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from callassist.classification import RuleClassifier, extract_fields
from callassist.config import Settings
from callassist.models import CallRequest
from callassist.monitoring import (
    Thresholds,
    monitor_results,
    persist_incident,
    word_error_rate,
)
from callassist.pii import redact_pii
from callassist.registry import ModelRegistry
from callassist.retrieval import LocalPolicyRetriever, load_policies
from callassist.service import CallAssistService
from callassist.workflow import build_workflow

ROOT = Path(__file__).resolve().parents[1]


class CoreTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory()
        self.settings = Settings(
            database_path=Path(self.temp.name) / "calls.db",
            policy_dir=ROOT / "data" / "policies",
            confidence_threshold=0.50,
        )
        self.service = CallAssistService(self.settings)

    def tearDown(self) -> None:
        self.temp.cleanup()

    def test_pii_redaction(self) -> None:
        text, counts = redact_pii("Email me at a@b.com or 571-555-0198; SSN 111-22-3333")
        self.assertNotIn("a@b.com", text)
        self.assertNotIn("571-555-0198", text)
        self.assertEqual(counts["SSN"], 1)

    def test_classification_and_sentiment(self) -> None:
        result = RuleClassifier().classify("I am angry about an unauthorized fraud charge")
        self.assertEqual(result.call_reason, "fraud_dispute")
        self.assertEqual(result.sentiment, "negative")

    def test_domain_paraphrases(self) -> None:
        classifier = RuleClassifier()
        self.assertEqual(
            classifier.classify("A purchase appeared that I never authorized").call_reason,
            "fraud_dispute",
        )
        self.assertEqual(
            classifier.classify("The remittance has not posted").call_reason,
            "payment_issue",
        )
        self.assertEqual(
            classifier.classify("Someone used my credit card without permission").call_reason,
            "fraud_dispute",
        )
        self.assertEqual(
            classifier.classify("The chip fails every time at checkout").call_reason,
            "card_access",
        )
        self.assertEqual(
            classifier.classify("My loyalty balance disappeared").call_reason,
            "rewards",
        )

    def test_field_extraction(self) -> None:
        fields = extract_fields("Charge from North Shop for $84.20 on Jan 12")
        self.assertEqual(fields["amount"], "84.20")
        self.assertEqual(fields["date"], "Jan 12")

    def test_merchant_stops_before_date(self) -> None:
        fields = extract_fields("Unauthorized $84 charge from North Shop on Sep 2.")
        self.assertEqual(fields["merchant"], "North Shop")

    def test_retrieval(self) -> None:
        retriever = LocalPolicyRetriever(load_policies(self.settings.policy_dir))
        policies = retriever.retrieve("unauthorized fraud charge not mine")
        self.assertEqual(policies[0].policy_id, "POL-FRAUD-001")

    def test_end_to_end_trace_and_audit(self) -> None:
        result = self.service.process(CallRequest("call-1", transcript="Unauthorized $84 charge from North Shop"))
        self.assertTrue(result.escalated)
        self.assertIn("high_risk_fraud_dispute", result.escalation_reasons)
        self.assertEqual(len(result.trace), 6)
        self.assertEqual(self.service.store.get_result("call-1")["call_id"], "call-1")

    def test_workflow_fallback(self) -> None:
        workflow = build_workflow(self.service)
        state = workflow.invoke({"request": CallRequest("call-2", transcript="My reward points are missing")})
        self.assertEqual(state["result"]["classification"]["call_reason"], "rewards")

    def test_account_change_requires_identity_verification(self) -> None:
        result = self.service.process(
            CallRequest("account-1", transcript="Please change the email on my profile")
        )
        self.assertTrue(result.escalated)
        self.assertIn("identity_verification_required", result.escalation_reasons)

    def test_monitoring_detects_shift(self) -> None:
        results = [
            self.service.process(CallRequest(f"m-{i}", transcript="An unknown question with no category")).to_dict()
            for i in range(4)
        ]
        report = monitor_results(
            results,
            Thresholds(min_confidence=0.0, max_escalation_rate=1.0, max_unknown_reason_rate=0.2),
            {"payment_issue": 1.0},
        )
        controls = {a["control"] for a in report.alerts}
        self.assertIn("unknown_reason_rate", controls)
        self.assertIn("reason_distribution_shift", controls)

    def test_word_error_rate(self) -> None:
        self.assertEqual(word_error_rate("a b c", "a b c"), 0.0)
        self.assertAlmostEqual(word_error_rate("a b c", "a x c"), 1 / 3)

    def test_registry_activation_and_rollback(self) -> None:
        registry = ModelRegistry(Path(self.temp.name) / "registry.db")
        registry.register("v1", {"threshold": 0.5}, {"f1": 0.8})
        registry.activate("v1")
        registry.register("v2", {"threshold": 0.6}, {"f1": 0.9})
        registry.activate("v2")
        self.assertEqual(registry.rollback(), "v1")
        self.assertEqual(registry.active(), "v1")

    def test_incident_persistence(self) -> None:
        path = Path(self.temp.name) / "incidents.jsonl"
        report = monitor_results([], Thresholds())
        incident = persist_incident(report, path)
        self.assertIsNotNone(incident)
        self.assertEqual(incident["status"], "open")
        self.assertTrue(path.exists())

    def test_settings_reads_cloud_audit_configuration(self) -> None:
        with patch.dict(
            os.environ,
            {"CALLASSIST_AUDIT_TABLE": "call-audits", "AWS_REGION": "us-west-2"},
        ):
            settings = Settings.from_env()
        self.assertEqual(settings.audit_table, "call-audits")
        self.assertEqual(settings.aws_region, "us-west-2")


if __name__ == "__main__":
    unittest.main()
