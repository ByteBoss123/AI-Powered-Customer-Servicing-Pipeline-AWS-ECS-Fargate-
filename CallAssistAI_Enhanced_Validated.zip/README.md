# CallAssist AI

CallAssist AI is an auditable, production-style GenAI pipeline for customer-servicing calls. It accepts transcripts or audio, redacts sensitive information, classifies call reason and sentiment, retrieves policy evidence, produces a grounded agent summary, and escalates risky or low-confidence decisions. Every step is recorded in a queryable audit trail and evaluated through repeatable quality controls.

This repository is a portfolio implementation. It does **not** claim enterprise traffic or real customer use. Scale, latency, and reliability claims must come from the included load test after deployment.

## What it demonstrates

- Audio/call-transcript processing with optional Whisper transcription
- LangGraph workflow orchestration with an offline-compatible runner
- LlamaIndex policy retrieval with deterministic local retrieval for CI
- Hugging Face generation with a grounded template provider for CI
- Weights & Biases Weave-compatible tracing plus persistent step-level audit logs
- PII redaction, confidence gating, fraud escalation, and policy grounding
- Call-reason and sentiment classification
- Golden-dataset evaluation, distribution-shift detection, and quality alerts
- Model version registration, activation, and rollback
- FastAPI endpoints, API-key authentication, Docker, GitHub Actions, Locust, and AWS ECS/Terraform

## Architecture

```mermaid
flowchart TD
    A[Audio or transcript] --> B[Whisper / transcript intake]
    B --> C[PII redaction]
    C --> D[Reason and sentiment]
    D --> E[LlamaIndex policy retrieval]
    E --> F[Hugging Face grounded response]
    F --> G[Confidence and risk gate]
    G --> H[Audit store and monitoring]
```

## Quick start

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -e ".[dev]"
cp .env.example .env
make test
make evaluate
make run
```

The default `local` provider mode is deterministic and requires no model download. To enable the real GenAI adapters:

```bash
python -m pip install -e ".[genai,dev]"
export CALLASSIST_PROVIDER_MODE=genai
export CALLASSIST_WHISPER_MODEL=base
export CALLASSIST_HF_MODEL=google/flan-t5-small
```

Initialize Weave in your deployment entrypoint when W&B credentials are configured; the `@traced` operations automatically become Weave operations when the package is installed.

## API

Start the service and submit a transcript:

```bash
curl -X POST http://localhost:8000/v1/calls/transcript \
  -H 'Content-Type: application/json' \
  -H 'X-API-Key: local-dev-key' \
  -d '{"call_id":"demo-1","transcript":"I am angry about an unauthorized $84 charge from North Shop."}'
```

Other endpoints:

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/health` | Container health check |
| POST | `/v1/calls/transcript` | Process a supplied transcript |
| POST | `/v1/calls/audio` | Process WAV, MP3, M4A, or FLAC audio |
| GET | `/v1/calls/{call_id}` | Retrieve a persisted audit record |
| GET | `/v1/monitoring/report` | Inspect aggregate quality controls and alerts |

## Evaluation and maintenance loop

`data/evaluation/calls.json` is a small, versioned golden dataset covering fraud, payments, card access, rewards, account updates, PII, and unknown requests.

```bash
python scripts/evaluate.py --fail-on-threshold
```

The quality gate requires:

- Call-reason macro F1 >= 0.80
- Escalation recall >= 0.95
- Zero known PII leakage

`ModelRegistry` stores version configuration and metrics, activates candidates, and rolls back to the prior version. `monitor_results` checks confidence, escalation rate, unknown-reason rate, and reason-distribution shift. These are concrete maintenance controls; they do not imply automated retraining.

Run the controlled threshold comparison and register the selected candidate:

```bash
python scripts/tune_threshold.py
```

The script retains the original `0.65` gate as `local-v1`, evaluates six candidates under the same golden dataset, registers the best eligible candidate as `local-v2`, and produces `artifacts/threshold_tuning.json`. This is intentionally separated from the main evaluation so changes remain reviewable and reversible.

The checked-in configuration uses the selected `0.45` threshold. See `MODEL_CARD.md` for the baseline comparison, limitations, and required next validation.

## Load testing

After starting the API:

```bash
locust -f locustfile.py --host http://localhost:8000
```

Record actual concurrency, throughput, P50/P95 latency, and error rate under `artifacts/`. Do not place unmeasured performance claims on a resume.

For a reproducible headless benchmark that starts the real Uvicorn API and records results:

```bash
python scripts/benchmark_api.py
```

## Executed audio and maintenance validation

Run real speech recognition against generated WAV speech (no transcript sidecars):

```bash
python scripts/evaluate_audio.py
```

This writes per-call Whisper transcripts, word-error rate, downstream reason accuracy,
escalation accuracy, and latency to `artifacts/audio_evaluation.json`.

Run the harder 20-call audio regression suite with paraphrases and degraded audio conditions:

```bash
python scripts/evaluate_audio_stress.py
```

The executed rerun produced 75% intent accuracy, 75% policy accuracy, 80% escalation
accuracy, and 10.7% mean WER. Results are stored in
`artifacts/audio_stress_evaluation.json`; all failed cases remain in the artifact.

Run the larger robustness benchmark with real Whisper inference:

```bash
python scripts/evaluate_audio_robustness.py
```

The benchmark evaluates 40 fixed utterances under clean, faster, telephone-band,
quiet, and pink-noise conditions. A separate 200-case untouched holdout is run with:

```bash
python scripts/evaluate_audio_robustness.py \
  --dataset data/evaluation/audio_holdout_cases.json \
  --benchmark-label untouched-holdout \
  --output artifacts/audio_robustness_holdout.json \
  --audio-dir artifacts/audio_robustness_holdout
```

It reports intent macro F1, policy Recall@1/Recall@3, escalation precision/recall,
false-escalation rate, WER, Brier score, expected calibration error, and latency.
See `artifacts/VALIDATION_REPORT.md` for the reproduced development comparison,
holdout metrics, condition slices, maintenance drill, and explicit claim boundaries.

Execute a forced distribution-shift incident and model rollback drill:

```bash
python scripts/maintenance_cycle.py
```

This writes the alert, runbook, promotion freeze, and rollback evidence under `artifacts/`.

## AWS deployment

The Terraform configuration provisions encrypted private S3 storage, DynamoDB audit
persistence, an Application Load Balancer, an autoscaled ECS Fargate service,
least-privilege task roles, Secrets Manager integration, Container Insights,
CloudWatch alarms, private task networking, and rolling deployments. Supply an
existing VPC, task and load-balancer subnets, image URI, and API-key secret ARN.

```bash
cd infra/terraform
terraform init
terraform plan \
  -var='container_image=ACCOUNT.dkr.ecr.us-east-1.amazonaws.com/callassist:latest' \
  -var='api_key_secret_arn=arn:aws:secretsmanager:...' \
  -var='vpc_id=vpc-...' \
  -var='private_subnet_ids=["subnet-...","subnet-..."]' \
  -var='load_balancer_subnet_ids=["subnet-...","subnet-..."]'
```

`.github/workflows/deploy.yml` performs tests and evaluation, authenticates to AWS
through GitHub OIDC, pushes an immutable image to ECR, validates Terraform, and
applies the deployment. The workflow requires repository secrets and variables;
its presence does not imply that a cloud deployment has occurred.

After deployment, record remote endpoint evidence with:

```bash
python scripts/benchmark_remote.py --url http://LOAD_BALANCER_DNS --api-key "$CALLASSIST_API_KEY"
```

## Security and limitations

- Synthetic examples only; never commit real customer audio or account data.
- The regex redactor is defense in depth, not a substitute for an enterprise DLP service.
- The local generator is deterministic and intended for CI, not natural-language quality benchmarking.
- Real model quality varies by selected checkpoints, audio conditions, and hardware.
- Authentication is a minimal API-key example. Production deployments should use an identity provider, rate limiting, private ingress, KMS keys, and retention policies.
- SQLite supports local reproducibility. Use a managed relational database for multiple API replicas.

## Resume language after measurement

Use only numbers produced by your own evaluation and deployment:

> Built and evaluated an auditable GenAI call-analysis workflow using Whisper, LangGraph, LlamaIndex, Hugging Face, and Weave, achieving **[measured macro F1]** call-reason classification and **[measured escalation recall]** on **[dataset size]** synthetic calls.

> Containerized the FastAPI service and load-tested it at **[concurrency]**, achieving **[P95 latency]**, **[throughput]**, and **[error rate]**.
