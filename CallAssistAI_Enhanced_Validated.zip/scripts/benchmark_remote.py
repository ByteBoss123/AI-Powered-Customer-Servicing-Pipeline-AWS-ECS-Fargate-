from __future__ import annotations

import argparse
import concurrent.futures
import json
import os
import time
import uuid
from pathlib import Path

import requests

ROOT = Path(__file__).resolve().parents[1]


def percentile(values: list[float], fraction: float) -> float:
    ordered = sorted(values)
    if not ordered:
        return 0.0
    index = min(len(ordered) - 1, round((len(ordered) - 1) * fraction))
    return ordered[index]


def worker(
    base_url: str, api_key: str, deadline: float, timeout: float
) -> tuple[list[float], int]:
    session = requests.Session()
    latencies: list[float] = []
    errors = 0
    while time.perf_counter() < deadline:
        started = time.perf_counter()
        try:
            response = session.post(
                f"{base_url}/v1/calls/transcript",
                headers={"X-API-Key": api_key},
                json={
                    "call_id": str(uuid.uuid4()),
                    "transcript": "My payment of $125 is still pending.",
                },
                timeout=timeout,
            )
            errors += int(response.status_code != 200)
        except requests.RequestException:
            errors += 1
        latencies.append((time.perf_counter() - started) * 1000)
    return latencies, errors


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--url", default=os.getenv("CALLASSIST_REMOTE_URL"))
    parser.add_argument("--api-key", default=os.getenv("CALLASSIST_API_KEY"))
    parser.add_argument("--concurrency", type=int, default=20)
    parser.add_argument("--duration", type=int, default=60)
    parser.add_argument("--timeout", type=float, default=10.0)
    parser.add_argument(
        "--output", default=str(ROOT / "artifacts" / "remote_api_benchmark.json")
    )
    args = parser.parse_args()
    if not args.url or not args.api_key:
        raise SystemExit("Set --url and --api-key or the corresponding environment variables")
    base_url = args.url.rstrip("/")
    health = requests.get(f"{base_url}/health", timeout=args.timeout)
    health.raise_for_status()
    started = time.perf_counter()
    deadline = started + args.duration
    with concurrent.futures.ThreadPoolExecutor(max_workers=args.concurrency) as executor:
        results = list(
            executor.map(
                lambda _: worker(base_url, args.api_key, deadline, args.timeout),
                range(args.concurrency),
            )
        )
    elapsed = time.perf_counter() - started
    latencies = [latency for batch, _ in results for latency in batch]
    errors = sum(count for _, count in results)
    payload = {
        "environment": "remote HTTP endpoint",
        "endpoint": "/v1/calls/transcript",
        "concurrency": args.concurrency,
        "duration_seconds": elapsed,
        "requests": len(latencies),
        "throughput_rps": len(latencies) / elapsed,
        "p50_latency_ms": percentile(latencies, 0.50),
        "p95_latency_ms": percentile(latencies, 0.95),
        "p99_latency_ms": percentile(latencies, 0.99),
        "error_rate": errors / max(len(latencies), 1),
    }
    Path(args.output).write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(payload, indent=2))


if __name__ == "__main__":
    main()
