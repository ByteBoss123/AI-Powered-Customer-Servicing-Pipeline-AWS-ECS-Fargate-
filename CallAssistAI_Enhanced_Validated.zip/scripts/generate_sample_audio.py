from __future__ import annotations

import math
import struct
import wave
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "artifacts" / "sample_call.wav"
OUT.parent.mkdir(parents=True, exist_ok=True)
sample_rate, seconds, frequency = 16_000, 1, 440
with wave.open(str(OUT), "wb") as audio:
    audio.setnchannels(1)
    audio.setsampwidth(2)
    audio.setframerate(sample_rate)
    for i in range(sample_rate * seconds):
        value = int(4_000 * math.sin(2 * math.pi * frequency * i / sample_rate))
        audio.writeframes(struct.pack("<h", value))
Path(str(OUT) + ".txt").write_text(
    "I need to dispute an unauthorized $84 charge from North Shop.", encoding="utf-8"
)
print(OUT)

