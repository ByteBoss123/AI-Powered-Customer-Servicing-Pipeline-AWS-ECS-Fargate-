from __future__ import annotations

import concurrent.futures
import json
import os
import subprocess
import sys
import time
import uuid
from pathlib import Path

import requests

ROOT = Path(__file__).resolve().parents[1]
URL = "http://127.0.0.1:8002"
CONCURRENCY = 20
DURATION_SECONDS = 15


def percentile(values: list[float], percentage: float) -> float:
    ordered = sorted(values)
    index = min(len(ordered) - 1, round((len(ordered) - 1) * percentage))
    return ordered[index]


def worker(deadline: float) -> tuple[list[float], int]:
    session = requests.Session()
    latencies, errors = [], 0
    while time.perf_counter() < deadline:
        started = time.perf_counter()
        try:
            response = session.post(
                f"{URL}/v1/calls/transcript",
                headers={"X-API-Key": "local-dev-key"},
                json={"call_id": str(uuid.uuid4()), "transcript": "My payment of $125 is still pending."},
                timeout=5,
            )
            if response.status_code != 200:
                errors += 1
        except requests.RequestException:
            errors += 1
        latencies.append((time.perf_counter() - started) * 1000)
    return latencies, errors


def main() -> None:
    env = os.environ.copy()
    env["PYTHONPATH"] = str(ROOT / "src")
    env["CALLASSIST_DATABASE_PATH"] = str(ROOT / "artifacts" / "benchmark.db")
    server = subprocess.Popen(
        [sys.executable, "-m", "uvicorn", "callassist.api:app", "--host", "127.0.0.1", "--port", "8002", "--log-level", "warning"],
        cwd=ROOT,
        env=env,
    )
    try:
        for _ in range(50):
            try:
                if requests.get(f"{URL}/health", timeout=0.2).status_code == 200:
                    break
            except requests.RequestException:
                time.sleep(0.1)
        else:
            raise RuntimeError("API server did not become ready")
        started = time.perf_counter()
        deadline = started + DURATION_SECONDS
        with concurrent.futures.ThreadPoolExecutor(max_workers=CONCURRENCY) as executor:
            results = list(executor.map(worker, [deadline] * CONCURRENCY))
        elapsed = time.perf_counter() - started
        latencies = [latency for batch, _ in results for latency in batch]
        errors = sum(count for _, count in results)
        metrics = {
            "concurrency": CONCURRENCY,
            "duration_seconds": elapsed,
            "requests": len(latencies),
            "throughput_rps": len(latencies) / elapsed,
            "p50_latency_ms": percentile(latencies, 0.50),
            "p95_latency_ms": percentile(latencies, 0.95),
            "p99_latency_ms": percentile(latencies, 0.99),
            "error_rate": errors / len(latencies),
            "endpoint": "/v1/calls/transcript",
            "environment": "local CPU, Uvicorn, SQLite",
        }
        (ROOT / "artifacts" / "api_benchmark.json").write_text(json.dumps(metrics, indent=2), encoding="utf-8")
        print(json.dumps(metrics, indent=2))
    finally:
        server.terminate()
        server.wait(timeout=5)


if __name__ == "__main__":
    main()
