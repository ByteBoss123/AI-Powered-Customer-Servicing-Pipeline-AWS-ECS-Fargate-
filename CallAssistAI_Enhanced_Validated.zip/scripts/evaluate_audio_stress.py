from __future__ import annotations

import json
import re
import subprocess
import time
from pathlib import Path

from callassist.audio import WhisperTranscriber
from callassist.config import Settings
from callassist.models import CallRequest
from callassist.monitoring import word_error_rate
from callassist.service import CallAssistService

ROOT = Path(__file__).resolve().parents[1]
OUT_DIR = ROOT / "artifacts" / "audio_stress"
OUT = ROOT / "artifacts" / "audio_stress_evaluation.json"

# Fixed before execution: 20 holdout utterances, including five deliberately
# out-of-vocabulary paraphrases and four repeatable audio conditions.
CASES = [
    ("fraud_1", "There is an unauthorized $84 charge from North Shop.", "fraud_dispute", True, "POL-FRAUD-001"),
    ("fraud_2", "This transaction is not mine and I want to dispute it.", "fraud_dispute", True, "POL-FRAUD-001"),
    ("fraud_3", "My card was stolen and somebody made a charge.", "fraud_dispute", True, "POL-FRAUD-001"),
    ("fraud_4", "A purchase appeared that I never authorized.", "fraud_dispute", True, "POL-FRAUD-001"),
    ("payment_1", "My payment of $125 is still pending.", "payment_issue", False, "POL-PAY-001"),
    ("payment_2", "I paid yesterday but the balance did not update.", "payment_issue", False, "POL-PAY-001"),
    ("payment_3", "Autopay failed and I received a late fee.", "payment_issue", False, "POL-PAY-001"),
    ("payment_4", "The remittance has not posted to my balance.", "payment_issue", False, "POL-PAY-001"),
    ("card_1", "My card is locked and I need a replacement.", "card_access", False, "POL-CARD-001"),
    ("card_2", "The card was declined at the grocery store.", "card_access", False, "POL-CARD-001"),
    ("card_3", "Please help me activate my new card.", "card_access", False, "POL-CARD-001"),
    ("card_4", "The plastic will not work at checkout.", "card_access", False, "POL-CARD-001"),
    ("rewards_1", "My reward points are missing.", "rewards", False, "POL-REWARD-001"),
    ("rewards_2", "I did not receive cashback for this purchase.", "rewards", False, "POL-REWARD-001"),
    ("rewards_3", "How many miles did I earn last month?", "rewards", False, "POL-REWARD-001"),
    ("rewards_4", "My loyalty balance disappeared.", "rewards", False, "POL-REWARD-001"),
    ("account_1", "Please change the email on my profile.", "account_information", True, "POL-ACCOUNT-001"),
    ("account_2", "I need to update my phone number.", "account_information", True, "POL-ACCOUNT-001"),
    ("account_3", "My billing address has changed.", "account_information", True, "POL-ACCOUNT-001"),
    ("account_4", "Update where statements are mailed.", "account_information", True, "POL-ACCOUNT-001"),
]
FILTERS = ["anull", "atempo=1.15", "highpass=f=250,lowpass=f=3000", "volume=0.45"]


def normalize(text: str) -> str:
    return " ".join(re.findall(r"[a-z0-9]+", text.lower().replace("$", "")))


def synthesize(text: str, output: Path, audio_filter: str) -> None:
    clean = output.with_suffix(".clean.wav")
    subprocess.run(
        ["ffmpeg", "-y", "-hide_banner", "-loglevel", "error", "-f", "lavfi", "-i", f"flite=text='{text}'", "-ar", "16000", "-ac", "1", str(clean)],
        check=True,
    )
    subprocess.run(
        ["ffmpeg", "-y", "-hide_banner", "-loglevel", "error", "-i", str(clean), "-af", audio_filter, "-ar", "16000", "-ac", "1", str(output)],
        check=True,
    )
    clean.unlink()


def main() -> None:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    transcriber = WhisperTranscriber("tiny.en")
    service = CallAssistService(
        Settings(database_path=ROOT / "artifacts" / "audio_stress.db", policy_dir=ROOT / "data" / "policies"),
        transcriber=transcriber,
    )
    rows = []
    for index, (name, reference, reason, escalation, policy) in enumerate(CASES):
        path = OUT_DIR / f"{name}.wav"
        condition = FILTERS[index % len(FILTERS)]
        synthesize(reference, path, condition)
        started = time.perf_counter()
        result = service.process(CallRequest(call_id=f"stress-{name}", audio_path=str(path)))
        latency_ms = (time.perf_counter() - started) * 1000
        retrieved = result.retrieved_policies[0].policy_id if result.retrieved_policies else None
        rows.append({
            "case": name,
            "condition": condition,
            "reference": reference,
            "hypothesis": result.redacted_transcript,
            "wer": word_error_rate(normalize(reference), normalize(result.redacted_transcript)),
            "latency_ms": latency_ms,
            "expected_reason": reason,
            "predicted_reason": result.classification.call_reason,
            "reason_correct": result.classification.call_reason == reason,
            "expected_escalation": escalation,
            "predicted_escalation": result.escalated,
            "escalation_correct": result.escalated == escalation,
            "expected_policy": policy,
            "retrieved_policy": retrieved,
            "policy_correct": retrieved == policy,
        })
    metrics = {
        "audio_cases": len(rows),
        "mean_wer": sum(row["wer"] for row in rows) / len(rows),
        "reason_accuracy": sum(row["reason_correct"] for row in rows) / len(rows),
        "escalation_accuracy": sum(row["escalation_correct"] for row in rows) / len(rows),
        "policy_accuracy": sum(row["policy_correct"] for row in rows) / len(rows),
        "mean_latency_ms": sum(row["latency_ms"] for row in rows) / len(rows),
        "model": "openai-whisper tiny.en",
        "audio_source": "FFmpeg Flite with speed, band-limit, and low-volume conditions",
    }
    OUT.write_text(json.dumps({"metrics": metrics, "cases": rows}, indent=2), encoding="utf-8")
    print(json.dumps(metrics, indent=2))


if __name__ == "__main__":
    main()
