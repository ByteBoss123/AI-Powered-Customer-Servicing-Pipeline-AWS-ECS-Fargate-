#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
export PYTHONPATH=src
export CALLASSIST_DATABASE_PATH="$ROOT/artifacts/loadtest.db"

python -m uvicorn callassist.api:app --host 127.0.0.1 --port 8001 >artifacts/loadtest-server.log 2>&1 &
server_pid=$!
trap 'kill "$server_pid" 2>/dev/null || true' EXIT

for _ in $(seq 1 30); do
  if curl -fsS http://127.0.0.1:8001/health >/dev/null; then
    break
  fi
  sleep 0.2
done

python -m locust -f locustfile.py --host http://127.0.0.1:8001 \
  --headless -u 20 -r 5 -t 15s --csv artifacts/loadtest --only-summary
