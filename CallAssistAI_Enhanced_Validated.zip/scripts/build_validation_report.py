from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ARTIFACTS = ROOT / "artifacts"


def load(name: str) -> dict:
    return json.loads((ARTIFACTS / name).read_text(encoding="utf-8"))


def percent(value: float) -> str:
    return f"{100 * value:.1f}%"


def main() -> None:
    baseline = load("audio_robustness_development_baseline.json")["metrics"]
    updated = load("audio_robustness_development_updated.json")["metrics"]
    holdout_payload = load("audio_robustness_holdout.json")
    holdout = holdout_payload["metrics"]
    maintenance = load("maintenance_run.json")
    lines = [
        "# CallAssist AI validation report",
        "",
        "## Evaluation design",
        "",
        "- Development benchmark: 40 fixed utterances x five acoustic conditions.",
        "- Untouched holdout: 40 newly authored utterances x the same five conditions.",
        "- Conditions: clean, faster speech, telephone band-limit, quiet speech, and pink noise.",
        "- Speech recognition: OpenAI Whisper `tiny.en`; no transcript sidecars.",
        "- The holdout was authored after the development vocabulary update and was not used for tuning.",
        "",
        "## Development comparison",
        "",
        "| Metric | Initial | Updated |",
        "|---|---:|---:|",
        f"| Intent macro F1 | {percent(baseline['reason_macro_f1'])} | {percent(updated['reason_macro_f1'])} |",
        f"| Policy Recall@1 | {percent(baseline['policy_recall_at_1'])} | {percent(updated['policy_recall_at_1'])} |",
        f"| Policy Recall@3 | {percent(baseline['policy_recall_at_3'])} | {percent(updated['policy_recall_at_3'])} |",
        f"| Escalation precision | {percent(baseline['escalation_precision'])} | {percent(updated['escalation_precision'])} |",
        f"| Escalation recall | {percent(baseline['escalation_recall'])} | {percent(updated['escalation_recall'])} |",
        f"| False-escalation rate | {percent(baseline['false_escalation_rate'])} | {percent(updated['false_escalation_rate'])} |",
        f"| Mean WER | {percent(baseline['mean_wer'])} | {percent(updated['mean_wer'])} |",
        "",
        "## Untouched holdout results",
        "",
        "| Metric | Result |",
        "|---|---:|",
        f"| Audio cases | {holdout['audio_cases']} |",
        f"| Unique utterances | {holdout['unique_utterances']} |",
        f"| Intent accuracy | {percent(holdout['reason_accuracy'])} |",
        f"| Intent macro F1 | {percent(holdout['reason_macro_f1'])} |",
        f"| Policy Recall@1 / Recall@3 | {percent(holdout['policy_recall_at_1'])} / {percent(holdout['policy_recall_at_3'])} |",
        f"| Escalation precision / recall | {percent(holdout['escalation_precision'])} / {percent(holdout['escalation_recall'])} |",
        f"| False-escalation rate | {percent(holdout['false_escalation_rate'])} |",
        f"| Mean WER | {percent(holdout['mean_wer'])} |",
        f"| Brier score / ECE | {holdout['reason_brier_score']:.3f} / {holdout['reason_expected_calibration_error']:.3f} |",
        f"| Mean / p95 end-to-end latency | {holdout['mean_end_to_end_latency_ms']:.0f} ms / {holdout['p95_end_to_end_latency_ms']:.0f} ms |",
        "",
        "### Results by acoustic condition",
        "",
        "| Condition | Macro F1 | Recall@3 | WER | P95 latency |",
        "|---|---:|---:|---:|---:|",
    ]
    for condition, metrics in holdout_payload["condition_metrics"].items():
        lines.append(
            f"| {condition} | {percent(metrics['reason_macro_f1'])} | "
            f"{percent(metrics['policy_recall_at_3'])} | {percent(metrics['mean_wer'])} | "
            f"{metrics['p95_end_to_end_latency_ms']:.0f} ms |"
        )
    lines.extend(
        [
            "",
            "## Maintenance-control drill",
            "",
            f"- Detected {maintenance['anomaly_scenarios_detected']} of {maintenance['controls_tested']} injected failure scenarios.",
            f"- Healthy-control false alarms: {maintenance['healthy_scenario_false_alarms']}.",
            f"- Incidents persisted: {maintenance['incidents_created']}.",
            f"- Promotion freeze: {maintenance['promotion_frozen']}.",
            f"- Rollback success: {maintenance['rollback_success']} to `{maintenance['rolled_back_to']}`.",
            "",
            "## Claim boundaries",
            "",
            "- All audio is synthetic; there are no real customers or external users.",
            "- Latency was measured on a local CPU, not AWS.",
            "- The remote benchmark and AWS deployment workflow are implemented but not executed without an AWS account.",
            "- Escalation recall is high because fraud and identity changes are intentionally routed to human review.",
            "- Calibration error and false escalations remain improvement opportunities.",
            "",
        ]
    )
    (ARTIFACTS / "VALIDATION_REPORT.md").write_text("\n".join(lines), encoding="utf-8")


if __name__ == "__main__":
    main()
