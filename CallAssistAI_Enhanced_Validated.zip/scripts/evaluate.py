from __future__ import annotations

import argparse
import json
import tempfile
from pathlib import Path

from callassist.config import Settings
from callassist.evaluation import evaluate
from callassist.service import CallAssistService

ROOT = Path(__file__).resolve().parents[1]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--fail-on-threshold", action="store_true")
    parser.add_argument("--output", default=str(ROOT / "artifacts" / "evaluation.json"))
    args = parser.parse_args()
    Path(args.output).parent.mkdir(parents=True, exist_ok=True)
    db_path = Path(tempfile.gettempdir()) / "callassist-evaluation.db"
    settings = Settings(database_path=db_path, policy_dir=ROOT / "data" / "policies")
    metrics = evaluate(CallAssistService(settings), ROOT / "data" / "evaluation" / "calls.json")
    Path(args.output).write_text(json.dumps(metrics, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(metrics, indent=2))
    if args.fail_on_threshold:
        passed = (
            metrics["reason_macro_f1"] >= 0.80
            and metrics["escalation_recall"] >= 0.95
            and metrics["pii_leaks"] == 0
        )
        if not passed:
            raise SystemExit("Evaluation thresholds failed")


if __name__ == "__main__":
    main()
