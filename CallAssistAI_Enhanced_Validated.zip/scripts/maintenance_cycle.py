from __future__ import annotations

import json
import time
from pathlib import Path

from callassist.monitoring import Thresholds, monitor_results, persist_incident
from callassist.registry import ModelRegistry

ROOT = Path(__file__).resolve().parents[1]


def result(reason: str, confidence: float, escalated: bool = False) -> dict:
    return {
        "confidence": confidence,
        "classification": {"call_reason": reason},
        "escalated": escalated,
    }


def main() -> None:
    artifacts = ROOT / "artifacts"
    incident_path = artifacts / "incidents.jsonl"
    registry_path = artifacts / "maintenance_registry.db"
    incident_path.unlink(missing_ok=True)
    registry_path.unlink(missing_ok=True)
    baseline = {
        "payment_issue": 0.4,
        "fraud_dispute": 0.2,
        "card_access": 0.2,
        "rewards": 0.2,
    }
    healthy = (
        [result("payment_issue", 0.82) for _ in range(8)]
        + [result("fraud_dispute", 0.86, True) for _ in range(4)]
        + [result("card_access", 0.79) for _ in range(4)]
        + [result("rewards", 0.81) for _ in range(4)]
    )
    scenarios = {
        "reason_distribution_shift": [result("other", 0.35, True) for _ in range(20)],
        "low_confidence": [result("payment_issue", 0.25) for _ in range(20)],
        "escalation_spike": [result("payment_issue", 0.80, True) for _ in range(20)],
    }
    healthy_report = monitor_results(healthy, Thresholds(), baseline)
    scenario_reports = {
        name: monitor_results(rows, Thresholds(), baseline)
        for name, rows in scenarios.items()
    }
    incidents = {
        name: persist_incident(report, incident_path)
        for name, report in scenario_reports.items()
    }

    registry = ModelRegistry(registry_path)
    registry.register("maint-v1", {"threshold": 0.65}, {"macro_f1": 0.87})
    registry.activate("maint-v1")
    registry.register("maint-v2", {"threshold": 0.45}, {"macro_f1": 0.90})
    registry.activate("maint-v2")
    rollback_started = time.perf_counter()
    rolled_back_to = registry.rollback()
    rollback_latency_ms = (time.perf_counter() - rollback_started) * 1000
    detected = sum(not report.healthy for report in scenario_reports.values())
    output = {
        "controls_tested": len(scenario_reports),
        "anomaly_scenarios_detected": detected,
        "detection_recall": detected / len(scenario_reports),
        "healthy_scenario_false_alarms": len(healthy_report.alerts),
        "incidents_created": sum(incident is not None for incident in incidents.values()),
        "promotion_frozen": all(incident is not None for incident in incidents.values()),
        "scenario_alerts": {
            name: report.alerts for name, report in scenario_reports.items()
        },
        "rolled_back_to": rolled_back_to,
        "active_model": registry.active(),
        "rollback_success": rolled_back_to == "maint-v1" and registry.active() == "maint-v1",
        "rollback_latency_ms": rollback_latency_ms,
    }
    (artifacts / "maintenance_run.json").write_text(json.dumps(output, indent=2), encoding="utf-8")
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()
