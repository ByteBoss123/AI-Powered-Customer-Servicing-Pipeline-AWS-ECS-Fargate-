from __future__ import annotations

import argparse
import json
import re
import statistics
import subprocess
import time
from collections import defaultdict
from pathlib import Path
from typing import Any

from callassist.audio import WhisperTranscriber
from callassist.config import Settings
from callassist.evaluation import (
    binary_classification_metrics,
    brier_score,
    expected_calibration_error,
    macro_f1,
)
from callassist.models import CallRequest
from callassist.monitoring import word_error_rate
from callassist.service import CallAssistService

ROOT = Path(__file__).resolve().parents[1]
MODEL_NAME = "tiny.en"

CONDITIONS: dict[str, str | None] = {
    "clean": "anull",
    "fast": "atempo=1.15",
    "telephone_band": "highpass=f=250,lowpass=f=3000",
    "quiet": "volume=0.45",
    "pink_noise": None,
}


def normalize(text: str) -> str:
    return " ".join(re.findall(r"[a-z0-9]+", text.lower().replace("$", "")))


def percentile(values: list[float], fraction: float) -> float:
    ordered = sorted(values)
    if not ordered:
        return 0.0
    index = min(len(ordered) - 1, round((len(ordered) - 1) * fraction))
    return ordered[index]


def synthesize_reference(text: str, output: Path) -> None:
    subprocess.run(
        [
            "ffmpeg",
            "-y",
            "-hide_banner",
            "-loglevel",
            "error",
            "-f",
            "lavfi",
            "-i",
            f"flite=text='{text}'",
            "-ar",
            "16000",
            "-ac",
            "1",
            str(output),
        ],
        check=True,
    )


def apply_condition(source: Path, output: Path, condition: str, audio_filter: str | None) -> None:
    if condition == "pink_noise":
        subprocess.run(
            [
                "ffmpeg",
                "-y",
                "-hide_banner",
                "-loglevel",
                "error",
                "-i",
                str(source),
                "-filter_complex",
                "[0:a]volume=1.0[s];"
                "anoisesrc=color=pink:amplitude=0.08:d=60:r=16000[n];"
                "[s][n]amix=inputs=2:duration=first:weights='1 0.25':normalize=0",
                "-ar",
                "16000",
                "-ac",
                "1",
                str(output),
            ],
            check=True,
        )
        return
    subprocess.run(
        [
            "ffmpeg",
            "-y",
            "-hide_banner",
            "-loglevel",
            "error",
            "-i",
            str(source),
            "-af",
            str(audio_filter),
            "-ar",
            "16000",
            "-ac",
            "1",
            str(output),
        ],
        check=True,
    )


def summarize(rows: list[dict[str, Any]]) -> dict[str, Any]:
    expected_reasons = [row["expected_reason"] for row in rows]
    predicted_reasons = [row["predicted_reason"] for row in rows]
    expected_escalations = [row["expected_escalation"] for row in rows]
    predicted_escalations = [row["predicted_escalation"] for row in rows]
    reason_correct = [row["reason_correct"] for row in rows]
    confidences = [row["reason_confidence"] for row in rows]
    escalation = binary_classification_metrics(expected_escalations, predicted_escalations)
    return {
        "audio_cases": len(rows),
        "unique_utterances": len({row["utterance_id"] for row in rows}),
        "acoustic_conditions": len({row["condition"] for row in rows}),
        "reason_accuracy": sum(reason_correct) / len(rows),
        "reason_macro_f1": macro_f1(expected_reasons, predicted_reasons),
        "policy_recall_at_1": sum(row["policy_at_1"] for row in rows) / len(rows),
        "policy_recall_at_3": sum(row["policy_at_3"] for row in rows) / len(rows),
        "escalation_precision": escalation["precision"],
        "escalation_recall": escalation["recall"],
        "escalation_f1": escalation["f1"],
        "false_escalation_rate": escalation["false_positive_rate"],
        "mean_wer": statistics.fmean(row["wer"] for row in rows),
        "reason_brier_score": brier_score(confidences, reason_correct),
        "reason_expected_calibration_error": expected_calibration_error(
            confidences, reason_correct
        ),
        "mean_end_to_end_latency_ms": statistics.fmean(row["latency_ms"] for row in rows),
        "p95_end_to_end_latency_ms": percentile(
            [row["latency_ms"] for row in rows], 0.95
        ),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--dataset", default=str(ROOT / "data" / "evaluation" / "audio_cases.json")
    )
    parser.add_argument(
        "--output", default=str(ROOT / "artifacts" / "audio_robustness_evaluation.json")
    )
    parser.add_argument(
        "--audio-dir", default=str(ROOT / "artifacts" / "audio_robustness")
    )
    parser.add_argument("--model", default=MODEL_NAME)
    parser.add_argument("--benchmark-label", default="development")
    args = parser.parse_args()
    dataset = Path(args.dataset).resolve()
    output = Path(args.output).resolve()
    out_dir = Path(args.audio_dir).resolve()
    cases = json.loads(dataset.read_text(encoding="utf-8"))
    out_dir.mkdir(parents=True, exist_ok=True)
    service = CallAssistService(
        Settings(
            database_path=ROOT / "artifacts" / "audio_robustness.db",
            policy_dir=ROOT / "data" / "policies",
        ),
        transcriber=WhisperTranscriber(args.model),
    )
    rows: list[dict[str, Any]] = []
    by_condition: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for case in cases:
        source = out_dir / f"{case['id']}.source.wav"
        synthesize_reference(case["text"], source)
        for condition, audio_filter in CONDITIONS.items():
            path = out_dir / f"{case['id']}.{condition}.wav"
            apply_condition(source, path, condition, audio_filter)
            started = time.perf_counter()
            result = service.process(
                CallRequest(
                    call_id=f"robust-{case['id']}-{condition}", audio_path=str(path)
                )
            )
            latency_ms = (time.perf_counter() - started) * 1000
            retrieved = [policy.policy_id for policy in result.retrieved_policies]
            row = {
                "utterance_id": case["id"],
                "condition": condition,
                "reference": case["text"],
                "hypothesis": result.redacted_transcript,
                "wer": word_error_rate(
                    normalize(case["text"]), normalize(result.redacted_transcript)
                ),
                "latency_ms": latency_ms,
                "expected_reason": case["reason"],
                "predicted_reason": result.classification.call_reason,
                "reason_confidence": result.classification.reason_confidence,
                "reason_correct": result.classification.call_reason == case["reason"],
                "expected_escalation": bool(case["escalate"]),
                "predicted_escalation": result.escalated,
                "expected_policy": case["policy"],
                "retrieved_policies": retrieved,
                "policy_at_1": bool(retrieved and retrieved[0] == case["policy"]),
                "policy_at_3": case["policy"] in retrieved[:3],
            }
            rows.append(row)
            by_condition[condition].append(row)
    payload = {
        "benchmark": {
            "label": args.benchmark_label,
            "dataset": str(dataset.relative_to(ROOT)),
            "model": f"openai-whisper {args.model}",
            "audio_source": "FFmpeg Flite synthetic speech",
            "design": "40 fixed utterances x 5 repeatable acoustic conditions",
            "tuning_policy": "No classifier or threshold changes were made against this benchmark",
        },
        "metrics": summarize(rows),
        "condition_metrics": {
            condition: summarize(condition_rows)
            for condition, condition_rows in sorted(by_condition.items())
        },
        "cases": rows,
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"metrics": payload["metrics"], "condition_metrics": payload["condition_metrics"]}, indent=2))


if __name__ == "__main__":
    main()
