from __future__ import annotations

import json
import re
import subprocess
import time
from pathlib import Path

from callassist.audio import WhisperTranscriber
from callassist.config import Settings
from callassist.models import CallRequest
from callassist.monitoring import word_error_rate
from callassist.service import CallAssistService

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "artifacts" / "audio_evaluation.json"
AUDIO_DIR = ROOT / "artifacts" / "audio_eval"
CASES = [
    ("fraud", "I need to dispute an unauthorized $84 charge from North Shop.", "fraud_dispute", True, "POL-FRAUD-001", {"amount": "84", "merchant": "North Shop"}),
    ("payment", "My payment of $125 is still pending.", "payment_issue", False, "POL-PAY-001", {"amount": "125"}),
    ("rewards", "My reward points are missing from my account.", "rewards", False, "POL-REWARD-001", {}),
    ("card", "My card is locked and I need a replacement.", "card_access", False, "POL-CARD-001", {}),
    ("account", "Please change the email on my profile.", "account_information", True, "POL-ACCOUNT-001", {}),
]


def normalize(text: str) -> str:
    return " ".join(re.findall(r"[a-z0-9]+", text.lower().replace("$", "")))


def main() -> None:
    AUDIO_DIR.mkdir(parents=True, exist_ok=True)
    transcriber = WhisperTranscriber("tiny.en")
    service = CallAssistService(
        Settings(database_path=ROOT / "artifacts" / "audio_eval.db", policy_dir=ROOT / "data" / "policies"),
        transcriber=transcriber,
    )
    rows = []
    for name, reference, expected_reason, expected_escalation, expected_policy, expected_fields in CASES:
        path = AUDIO_DIR / f"{name}.wav"
        subprocess.run(
            ["ffmpeg", "-y", "-hide_banner", "-loglevel", "error", "-f", "lavfi", "-i", f"flite=text='{reference}'", "-ar", "16000", "-ac", "1", str(path)],
            check=True,
        )
        started = time.perf_counter()
        result = service.process(CallRequest(call_id=f"audio-{name}", audio_path=str(path)))
        elapsed_ms = (time.perf_counter() - started) * 1000
        hypothesis = result.redacted_transcript
        policy_id = (
            result.retrieved_policies[0].policy_id
            if result.retrieved_policies and result.retrieved_policies[0].score > 0
            else None
        )
        fields_correct = all(result.extracted_fields.get(key) == value for key, value in expected_fields.items())
        rows.append({
            "case": name,
            "reference": reference,
            "hypothesis": hypothesis,
            "wer": word_error_rate(normalize(reference), normalize(hypothesis)),
            "latency_ms": elapsed_ms,
            "expected_reason": expected_reason,
            "predicted_reason": result.classification.call_reason,
            "reason_correct": result.classification.call_reason == expected_reason,
            "expected_escalation": expected_escalation,
            "escalation_correct": result.escalated == expected_escalation,
            "expected_policy": expected_policy,
            "retrieved_policy": policy_id,
            "policy_correct": policy_id == expected_policy,
            "expected_fields": expected_fields,
            "extracted_fields": result.extracted_fields,
            "fields_correct": fields_correct,
        })
    metrics = {
        "audio_cases": len(rows),
        "mean_wer": sum(row["wer"] for row in rows) / len(rows),
        "reason_accuracy": sum(row["reason_correct"] for row in rows) / len(rows),
        "escalation_accuracy": sum(row["escalation_correct"] for row in rows) / len(rows),
        "policy_accuracy": sum(row["policy_correct"] for row in rows) / len(rows),
        "field_accuracy": sum(row["fields_correct"] for row in rows) / len(rows),
        "mean_latency_ms": sum(row["latency_ms"] for row in rows) / len(rows),
        "max_latency_ms": max(row["latency_ms"] for row in rows),
        "model": "openai-whisper tiny.en",
        "audio_source": "FFmpeg Flite synthetic speech",
    }
    payload = {"metrics": metrics, "cases": rows}
    OUT.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    print(json.dumps(metrics, indent=2))


if __name__ == "__main__":
    main()
