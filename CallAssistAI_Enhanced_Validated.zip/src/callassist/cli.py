from __future__ import annotations

import argparse
import json

from .config import Settings
from .models import CallRequest
from .service import CallAssistService


def main() -> None:
    parser = argparse.ArgumentParser(description="Process a customer-servicing transcript")
    parser.add_argument("transcript")
    parser.add_argument("--call-id", default="cli-call")
    args = parser.parse_args()
    service = CallAssistService(Settings.from_env())
    result = service.process(CallRequest(call_id=args.call_id, transcript=args.transcript))
    print(json.dumps(result.to_dict(), indent=2))


if __name__ == "__main__":
    main()

