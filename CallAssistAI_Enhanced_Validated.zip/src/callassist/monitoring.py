from __future__ import annotations

import json
from collections import Counter
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


@dataclass
class Thresholds:
    min_confidence: float = 0.65
    max_escalation_rate: float = 0.45
    max_unknown_reason_rate: float = 0.20
    max_distribution_shift: float = 0.20


@dataclass
class MonitoringReport:
    sample_size: int
    metrics: dict[str, float]
    alerts: list[dict[str, Any]] = field(default_factory=list)

    @property
    def healthy(self) -> bool:
        return not self.alerts


def distribution(values: list[str]) -> dict[str, float]:
    if not values:
        return {}
    counts = Counter(values)
    return {key: count / len(values) for key, count in counts.items()}


def total_variation_distance(reference: dict[str, float], current: dict[str, float]) -> float:
    keys = reference.keys() | current.keys()
    return 0.5 * sum(abs(reference.get(key, 0.0) - current.get(key, 0.0)) for key in keys)


def monitor_results(
    results: list[dict[str, Any]],
    thresholds: Thresholds | None = None,
    reference_reason_distribution: dict[str, float] | None = None,
) -> MonitoringReport:
    thresholds = thresholds or Thresholds()
    if not results:
        return MonitoringReport(0, {}, [{"severity": "high", "control": "sample_size", "value": 0}])
    confidences = [float(item["confidence"]) for item in results]
    reasons = [item["classification"]["call_reason"] for item in results]
    escalation_rate = sum(bool(item["escalated"]) for item in results) / len(results)
    unknown_rate = sum(reason == "other" for reason in reasons) / len(reasons)
    metrics = {
        "mean_confidence": sum(confidences) / len(confidences),
        "escalation_rate": escalation_rate,
        "unknown_reason_rate": unknown_rate,
    }
    alerts = []
    if metrics["mean_confidence"] < thresholds.min_confidence:
        alerts.append({"severity": "high", "control": "mean_confidence", "value": metrics["mean_confidence"]})
    if escalation_rate > thresholds.max_escalation_rate:
        alerts.append({"severity": "medium", "control": "escalation_rate", "value": escalation_rate})
    if unknown_rate > thresholds.max_unknown_reason_rate:
        alerts.append({"severity": "high", "control": "unknown_reason_rate", "value": unknown_rate})
    if reference_reason_distribution:
        shift = total_variation_distance(reference_reason_distribution, distribution(reasons))
        metrics["reason_distribution_shift"] = shift
        if shift > thresholds.max_distribution_shift:
            alerts.append({"severity": "high", "control": "reason_distribution_shift", "value": shift})
    return MonitoringReport(len(results), metrics, alerts)


def persist_incident(report: MonitoringReport, path: Path) -> dict[str, Any] | None:
    """Persist an actionable incident record when a monitoring control fires."""
    if report.healthy:
        return None
    severity_order = {"low": 1, "medium": 2, "high": 3}
    incident = {
        "created_at": datetime.now(timezone.utc).isoformat(),
        "status": "open",
        "severity": max(
            (alert["severity"] for alert in report.alerts),
            key=lambda value: severity_order.get(value, 0),
        ),
        "sample_size": report.sample_size,
        "metrics": report.metrics,
        "alerts": report.alerts,
        "runbook": [
            "Freeze automatic model promotion",
            "Compare current inputs with the reference distribution",
            "Review low-confidence and escalated calls",
            "Rollback to the last approved model if quality regressed",
        ],
    }
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(incident, sort_keys=True) + "\n")
    return incident


def word_error_rate(reference: str, hypothesis: str) -> float:
    ref, hyp = reference.split(), hypothesis.split()
    previous = list(range(len(hyp) + 1))
    for i, ref_word in enumerate(ref, 1):
        current = [i]
        for j, hyp_word in enumerate(hyp, 1):
            current.append(min(current[-1] + 1, previous[j] + 1, previous[j - 1] + (ref_word != hyp_word)))
        previous = current
    return previous[-1] / max(len(ref), 1)
