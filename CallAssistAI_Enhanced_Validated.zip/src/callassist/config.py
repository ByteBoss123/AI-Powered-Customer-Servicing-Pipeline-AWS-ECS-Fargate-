from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path


def _project_root() -> Path:
    return Path(__file__).resolve().parents[2]


@dataclass(frozen=True)
class Settings:
    environment: str = "local"
    database_path: Path = _project_root() / "callassist.db"
    policy_dir: Path = _project_root() / "data" / "policies"
    provider_mode: str = "local"
    api_key: str = "local-dev-key"
    model_version: str = "local-v2"
    confidence_threshold: float = 0.45
    max_audio_mb: int = 25
    hf_model: str = "google/flan-t5-small"
    whisper_model: str = "base"
    audit_table: str | None = None
    aws_region: str = "us-east-1"

    @classmethod
    def from_env(cls) -> "Settings":
        return cls(
            environment=os.getenv("CALLASSIST_ENV", "local"),
            database_path=Path(os.getenv("CALLASSIST_DATABASE_PATH", str(cls.database_path))),
            policy_dir=Path(os.getenv("CALLASSIST_POLICY_DIR", str(cls.policy_dir))),
            provider_mode=os.getenv("CALLASSIST_PROVIDER_MODE", "local"),
            api_key=os.getenv("CALLASSIST_API_KEY", "local-dev-key"),
            model_version=os.getenv("CALLASSIST_MODEL_VERSION", "local-v2"),
            confidence_threshold=float(os.getenv("CALLASSIST_CONFIDENCE_THRESHOLD", "0.45")),
            max_audio_mb=int(os.getenv("CALLASSIST_MAX_AUDIO_MB", "25")),
            hf_model=os.getenv("CALLASSIST_HF_MODEL", "google/flan-t5-small"),
            whisper_model=os.getenv("CALLASSIST_WHISPER_MODEL", "base"),
            audit_table=os.getenv("CALLASSIST_AUDIT_TABLE") or None,
            aws_region=os.getenv("AWS_REGION", "us-east-1"),
        )
