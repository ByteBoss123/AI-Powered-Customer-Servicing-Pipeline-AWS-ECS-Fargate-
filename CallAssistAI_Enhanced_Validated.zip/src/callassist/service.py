from __future__ import annotations

import time
from pathlib import Path
from typing import Any

from .audio import SidecarTranscriber, Transcriber, WhisperTranscriber
from .classification import RuleClassifier, extract_fields
from .config import Settings
from .generation import Generator, HuggingFaceGenerator, TemplateGenerator
from .models import CallRequest, CallResult
from .observability import traced
from .pii import redact_pii
from .retrieval import LlamaIndexPolicyRetriever, LocalPolicyRetriever, load_policies
from .storage import AuditStore, DynamoDBAuditStore


class CallAssistService:
    def __init__(
        self,
        settings: Settings,
        transcriber: Transcriber | None = None,
        generator: Generator | None = None,
        retriever: Any | None = None,
    ) -> None:
        self.settings = settings
        documents = load_policies(settings.policy_dir)
        if settings.provider_mode == "genai":
            self.transcriber = transcriber or WhisperTranscriber(settings.whisper_model)
            self.generator = generator or HuggingFaceGenerator(settings.hf_model)
            self.retriever = retriever or LlamaIndexPolicyRetriever(documents)
        else:
            self.transcriber = transcriber or SidecarTranscriber()
            self.generator = generator or TemplateGenerator()
            self.retriever = retriever or LocalPolicyRetriever(documents)
        self.classifier = RuleClassifier()
        self.store = (
            DynamoDBAuditStore(settings.audit_table, settings.aws_region)
            if settings.audit_table
            else AuditStore(settings.database_path)
        )

    @traced("callassist.process_call")
    def process(self, request: CallRequest) -> CallResult:
        trace: list[dict[str, Any]] = []
        transcript, transcription_confidence = self._get_transcript(request)
        self._trace(trace, "transcription", transcription_confidence)

        redacted, pii_counts = redact_pii(transcript)
        self._trace(trace, "pii_redaction", 1.0, {"entities_redacted": pii_counts})

        classification = self.classifier.classify(redacted)
        self._trace(trace, "classification", classification.reason_confidence)

        fields = extract_fields(redacted)
        self._trace(trace, "field_extraction", 1.0 if fields else 0.6, {"field_count": len(fields)})

        policies = self.retriever.retrieve(f"{classification.call_reason} {redacted}", top_k=3)
        retrieval_confidence = policies[0].score if policies else 0.0
        self._trace(trace, "retrieval", retrieval_confidence, {"policy_ids": [p.policy_id for p in policies]})

        summary, action, generation_confidence = self.generator.generate(redacted, classification, policies)
        grounded = bool(policies) and policies[0].score > 0
        self._trace(trace, "generation", generation_confidence, {"grounded": grounded})

        confidence = round(min(transcription_confidence, classification.reason_confidence, generation_confidence), 4)
        reasons = []
        if confidence < self.settings.confidence_threshold:
            reasons.append("confidence_below_threshold")
        if not grounded:
            reasons.append("no_policy_grounding")
        if classification.call_reason == "fraud_dispute":
            reasons.append("high_risk_fraud_dispute")
        if classification.call_reason == "account_information":
            reasons.append("identity_verification_required")
        if classification.call_reason == "other":
            reasons.append("unsupported_call_reason")
        result = CallResult(
            call_id=request.call_id,
            redacted_transcript=redacted,
            classification=classification,
            extracted_fields=fields,
            retrieved_policies=policies,
            summary=summary,
            recommended_action=action,
            confidence=confidence,
            escalated=bool(reasons),
            escalation_reasons=reasons,
            model_version=self.settings.model_version,
            trace=trace,
        )
        self.store.save_result(result.to_dict())
        return result

    def _get_transcript(self, request: CallRequest) -> tuple[str, float]:
        if request.transcript and request.transcript.strip():
            return request.transcript.strip(), 1.0
        if request.audio_path:
            path = Path(request.audio_path)
            if path.stat().st_size > self.settings.max_audio_mb * 1024 * 1024:
                raise ValueError("Audio file exceeds configured size limit")
            return self.transcriber.transcribe(request.audio_path)
        raise ValueError("A transcript or audio_path is required")

    @staticmethod
    def _trace(trace: list[dict[str, Any]], step: str, confidence: float, metadata: dict | None = None) -> None:
        trace.append(
            {
                "step": step,
                "confidence": round(float(confidence), 4),
                "timestamp_ns": time.time_ns(),
                "metadata": metadata or {},
            }
        )
