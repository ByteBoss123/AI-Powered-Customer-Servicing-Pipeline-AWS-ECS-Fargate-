from __future__ import annotations

from functools import wraps
from typing import Any, Callable


def traced(name: str) -> Callable:
    """Use Weave tracing when installed; remain deterministic in local CI."""
    try:
        import weave

        return weave.op(name=name)
    except ImportError:
        def decorator(function: Callable) -> Callable:
            @wraps(function)
            def wrapper(*args: Any, **kwargs: Any) -> Any:
                return function(*args, **kwargs)
            return wrapper
        return decorator

