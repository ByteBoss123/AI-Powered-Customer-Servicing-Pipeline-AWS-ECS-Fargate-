from __future__ import annotations

from typing import Protocol

from .models import Classification, RetrievedPolicy


class Generator(Protocol):
    def generate(
        self,
        transcript: str,
        classification: Classification,
        policies: list[RetrievedPolicy],
    ) -> tuple[str, str, float]: ...


class TemplateGenerator:
    """Grounded deterministic generator used by CI and local evaluation."""

    def generate(
        self,
        transcript: str,
        classification: Classification,
        policies: list[RetrievedPolicy],
    ) -> tuple[str, str, float]:
        excerpt = transcript[:180].strip()
        title = policies[0].title if policies else "No matching policy"
        summary = f"Customer contacted servicing about {classification.call_reason}. {excerpt}"
        action = f"Review and follow policy: {title}."
        retrieval_score = policies[0].score if policies else 0.0
        confidence = round(0.55 * classification.reason_confidence + 0.45 * retrieval_score, 4)
        return summary, action, confidence


class HuggingFaceGenerator:
    def __init__(self, model_name: str) -> None:
        try:
            from transformers import pipeline
        except ImportError as exc:
            raise RuntimeError("Install callassist-ai[genai] to enable Hugging Face generation") from exc
        self.pipeline = pipeline("text2text-generation", model=model_name)

    def generate(
        self,
        transcript: str,
        classification: Classification,
        policies: list[RetrievedPolicy],
    ) -> tuple[str, str, float]:
        context = "\n".join(f"[{p.policy_id}] {p.text}" for p in policies)
        prompt = (
            "Summarize this customer-service call and recommend only actions supported by policy. "
            f"Call reason: {classification.call_reason}\nPolicies:\n{context}\nTranscript:\n{transcript}"
        )
        output = self.pipeline(prompt, max_new_tokens=180, do_sample=False)[0]["generated_text"]
        return output, f"Follow retrieved policy {policies[0].policy_id if policies else 'NONE'}", 0.75

