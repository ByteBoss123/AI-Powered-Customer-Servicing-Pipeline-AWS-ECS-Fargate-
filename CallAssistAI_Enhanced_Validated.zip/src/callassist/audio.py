from __future__ import annotations

import os
from pathlib import Path
from typing import Protocol


class Transcriber(Protocol):
    def transcribe(self, audio_path: str) -> tuple[str, float]: ...


class SidecarTranscriber:
    """Deterministic local transcriber: reads `<audio>.txt` for offline tests."""

    def transcribe(self, audio_path: str) -> tuple[str, float]:
        path = Path(audio_path)
        sidecar = Path(str(path) + ".txt")
        if not path.exists():
            raise FileNotFoundError(path)
        if not sidecar.exists():
            raise RuntimeError(f"Local mode expects transcript sidecar: {sidecar}")
        return sidecar.read_text(encoding="utf-8").strip(), 0.95


class WhisperTranscriber:
    def __init__(self, model_name: str = "base") -> None:
        try:
            import whisper
        except ImportError as exc:
            raise RuntimeError("Install callassist-ai[genai] to enable Whisper") from exc
        download_root = os.getenv("WHISPER_CACHE_DIR")
        self.model = whisper.load_model(model_name, download_root=download_root)

    def transcribe(self, audio_path: str) -> tuple[str, float]:
        result = self.model.transcribe(audio_path, fp16=False)
        segments = result.get("segments", [])
        avg_logprob = sum(s.get("avg_logprob", -1.0) for s in segments) / max(len(segments), 1)
        confidence = max(0.0, min(1.0, 1.0 + float(avg_logprob)))
        return str(result["text"]).strip(), confidence
