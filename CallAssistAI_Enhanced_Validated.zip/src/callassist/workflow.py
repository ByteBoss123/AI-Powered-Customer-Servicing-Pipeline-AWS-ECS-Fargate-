from __future__ import annotations

from typing import Any, TypedDict

from .models import CallRequest
from .service import CallAssistService


class WorkflowState(TypedDict, total=False):
    request: CallRequest
    result: dict[str, Any]


def build_workflow(service: CallAssistService) -> Any:
    """Build a genuine LangGraph workflow when installed, else a compatible local runner."""
    try:
        from langgraph.graph import END, StateGraph

        graph = StateGraph(WorkflowState)

        def process_node(state: WorkflowState) -> WorkflowState:
            return {"result": service.process(state["request"]).to_dict()}

        graph.add_node("process_call", process_node)
        graph.set_entry_point("process_call")
        graph.add_edge("process_call", END)
        return graph.compile()
    except ImportError:
        class LocalWorkflow:
            def invoke(self, state: WorkflowState) -> WorkflowState:
                return {"request": state["request"], "result": service.process(state["request"]).to_dict()}
        return LocalWorkflow()

