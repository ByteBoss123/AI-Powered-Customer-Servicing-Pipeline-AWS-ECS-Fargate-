from __future__ import annotations

from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from typing import Any


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


@dataclass
class CallRequest:
    call_id: str
    transcript: str | None = None
    audio_path: str | None = None
    customer_id: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class Classification:
    call_reason: str
    reason_confidence: float
    sentiment: str
    sentiment_confidence: float


@dataclass
class RetrievedPolicy:
    policy_id: str
    title: str
    text: str
    score: float


@dataclass
class CallResult:
    call_id: str
    redacted_transcript: str
    classification: Classification
    extracted_fields: dict[str, str]
    retrieved_policies: list[RetrievedPolicy]
    summary: str
    recommended_action: str
    confidence: float
    escalated: bool
    escalation_reasons: list[str]
    model_version: str
    trace: list[dict[str, Any]]
    created_at: str = field(default_factory=utc_now)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

