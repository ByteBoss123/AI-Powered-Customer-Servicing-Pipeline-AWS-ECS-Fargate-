from __future__ import annotations

import json
import sqlite3
from pathlib import Path
from typing import Any

from .models import utc_now


class ModelRegistry:
    def __init__(self, path: Path) -> None:
        self.path = path
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with sqlite3.connect(self.path) as db:
            db.executescript(
                """
                CREATE TABLE IF NOT EXISTS model_versions (
                  version TEXT PRIMARY KEY, created_at TEXT NOT NULL,
                  config_json TEXT NOT NULL, metrics_json TEXT NOT NULL,
                  status TEXT NOT NULL CHECK(status IN ('candidate','active','retired'))
                );
                """
            )

    def register(self, version: str, config: dict[str, Any], metrics: dict[str, float]) -> None:
        with sqlite3.connect(self.path) as db:
            db.execute(
                "INSERT OR REPLACE INTO model_versions VALUES (?, ?, ?, ?, 'candidate')",
                (version, utc_now(), json.dumps(config), json.dumps(metrics)),
            )

    def activate(self, version: str) -> None:
        with sqlite3.connect(self.path) as db:
            exists = db.execute("SELECT 1 FROM model_versions WHERE version = ?", (version,)).fetchone()
            if not exists:
                raise KeyError(f"Unknown model version: {version}")
            db.execute("UPDATE model_versions SET status = 'retired' WHERE status = 'active'")
            db.execute("UPDATE model_versions SET status = 'active' WHERE version = ?", (version,))

    def active(self) -> str | None:
        with sqlite3.connect(self.path) as db:
            row = db.execute("SELECT version FROM model_versions WHERE status = 'active'").fetchone()
        return row[0] if row else None

    def rollback(self) -> str:
        with sqlite3.connect(self.path) as db:
            rows = db.execute(
                "SELECT version, status FROM model_versions ORDER BY created_at DESC"
            ).fetchall()
            active_index = next((i for i, row in enumerate(rows) if row[1] == "active"), None)
            if active_index is None or active_index + 1 >= len(rows):
                raise RuntimeError("No prior model version available for rollback")
            target = rows[active_index + 1][0]
        self.activate(target)
        return target

