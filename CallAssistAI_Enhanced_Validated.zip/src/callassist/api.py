from __future__ import annotations

import hmac
import tempfile
import uuid
from pathlib import Path
from typing import Any

from fastapi import Depends, FastAPI, File, Header, HTTPException, UploadFile
from pydantic import BaseModel, Field

from .config import Settings
from .models import CallRequest
from .monitoring import monitor_results
from .service import CallAssistService
from .workflow import build_workflow

settings = Settings.from_env()
service = CallAssistService(settings)
workflow = build_workflow(service)
app = FastAPI(title="CallAssist AI", version="0.1.0", docs_url="/docs")


class TranscriptRequest(BaseModel):
    call_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    transcript: str = Field(min_length=3, max_length=100_000)
    customer_id: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


def authorize(x_api_key: str = Header(default="")) -> None:
    if not hmac.compare_digest(x_api_key, settings.api_key):
        raise HTTPException(status_code=401, detail="Invalid API key")


@app.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok", "provider_mode": settings.provider_mode}


@app.post("/v1/calls/transcript", dependencies=[Depends(authorize)])
def process_transcript(payload: TranscriptRequest) -> dict[str, Any]:
    state = workflow.invoke({"request": CallRequest(**payload.model_dump())})
    return state["result"]


@app.post("/v1/calls/audio", dependencies=[Depends(authorize)])
async def process_audio(file: UploadFile = File(...), call_id: str | None = None) -> dict[str, Any]:
    suffix = Path(file.filename or "audio.wav").suffix.lower()
    if suffix not in {".wav", ".mp3", ".m4a", ".flac"}:
        raise HTTPException(status_code=415, detail="Unsupported audio format")
    content = await file.read(settings.max_audio_mb * 1024 * 1024 + 1)
    if len(content) > settings.max_audio_mb * 1024 * 1024:
        raise HTTPException(status_code=413, detail="Audio exceeds size limit")
    with tempfile.NamedTemporaryFile(suffix=suffix, delete=False) as handle:
        handle.write(content)
        temp_path = handle.name
    try:
        state = workflow.invoke({"request": CallRequest(call_id=call_id or str(uuid.uuid4()), audio_path=temp_path)})
        return state["result"]
    finally:
        Path(temp_path).unlink(missing_ok=True)


@app.get("/v1/calls/{call_id}", dependencies=[Depends(authorize)])
def get_call(call_id: str) -> dict[str, Any]:
    result = service.store.get_result(call_id)
    if result is None:
        raise HTTPException(status_code=404, detail="Call not found")
    return result


@app.get("/v1/monitoring/report", dependencies=[Depends(authorize)])
def monitoring_report(limit: int = 100) -> dict[str, Any]:
    report = monitor_results(service.store.recent_results(min(max(limit, 1), 1000)))
    return {"healthy": report.healthy, "sample_size": report.sample_size, "metrics": report.metrics, "alerts": report.alerts}

