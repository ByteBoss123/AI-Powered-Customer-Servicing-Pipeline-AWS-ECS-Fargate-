from __future__ import annotations

import json
from collections import Counter
from pathlib import Path
from typing import Any

from .models import CallRequest
from .service import CallAssistService


def macro_f1(expected: list[str], predicted: list[str]) -> float:
    labels = sorted(set(expected) | set(predicted))
    scores = []
    for label in labels:
        tp = sum(e == label and p == label for e, p in zip(expected, predicted))
        fp = sum(e != label and p == label for e, p in zip(expected, predicted))
        fn = sum(e == label and p != label for e, p in zip(expected, predicted))
        precision = tp / (tp + fp) if tp + fp else 0.0
        recall = tp / (tp + fn) if tp + fn else 0.0
        scores.append(2 * precision * recall / (precision + recall) if precision + recall else 0.0)
    return sum(scores) / max(len(scores), 1)


def binary_classification_metrics(
    expected: list[bool], predicted: list[bool]
) -> dict[str, float]:
    if len(expected) != len(predicted):
        raise ValueError("Expected and predicted values must have equal length")
    tp = sum(e and p for e, p in zip(expected, predicted))
    tn = sum(not e and not p for e, p in zip(expected, predicted))
    fp = sum(not e and p for e, p in zip(expected, predicted))
    fn = sum(e and not p for e, p in zip(expected, predicted))
    precision = tp / (tp + fp) if tp + fp else 0.0
    recall = tp / (tp + fn) if tp + fn else 0.0
    f1 = 2 * precision * recall / (precision + recall) if precision + recall else 0.0
    return {
        "precision": precision,
        "recall": recall,
        "f1": f1,
        "accuracy": (tp + tn) / max(len(expected), 1),
        "false_positive_rate": fp / (fp + tn) if fp + tn else 0.0,
    }


def brier_score(confidences: list[float], correct: list[bool]) -> float:
    if len(confidences) != len(correct):
        raise ValueError("Confidence and correctness values must have equal length")
    if not confidences:
        return 0.0
    return sum((confidence - float(outcome)) ** 2 for confidence, outcome in zip(confidences, correct)) / len(confidences)


def expected_calibration_error(
    confidences: list[float], correct: list[bool], bins: int = 10
) -> float:
    if len(confidences) != len(correct):
        raise ValueError("Confidence and correctness values must have equal length")
    if bins < 1:
        raise ValueError("bins must be at least 1")
    if not confidences:
        return 0.0
    error = 0.0
    for index in range(bins):
        lower, upper = index / bins, (index + 1) / bins
        members = [
            i
            for i, confidence in enumerate(confidences)
            if lower <= confidence < upper or (index == bins - 1 and confidence == 1.0)
        ]
        if not members:
            continue
        mean_confidence = sum(confidences[i] for i in members) / len(members)
        accuracy = sum(correct[i] for i in members) / len(members)
        error += len(members) / len(confidences) * abs(mean_confidence - accuracy)
    return error


def evaluate(service: CallAssistService, dataset_path: Path) -> dict[str, Any]:
    records = json.loads(dataset_path.read_text(encoding="utf-8"))
    expected_reasons, predicted_reasons = [], []
    expected_escalations, predicted_escalations = [], []
    pii_leaks = 0
    results = []
    for row in records:
        result = service.process(CallRequest(call_id=f"eval-{row['id']}", transcript=row["transcript"]))
        expected_reasons.append(row["expected_reason"])
        predicted_reasons.append(result.classification.call_reason)
        expected_escalations.append(bool(row["should_escalate"]))
        predicted_escalations.append(result.escalated)
        for sensitive in row.get("sensitive_values", []):
            pii_leaks += int(sensitive in result.redacted_transcript)
        results.append(result.to_dict())
    tp = sum(e and p for e, p in zip(expected_escalations, predicted_escalations))
    fn = sum(e and not p for e, p in zip(expected_escalations, predicted_escalations))
    fp = sum(not e and p for e, p in zip(expected_escalations, predicted_escalations))
    return {
        "records": len(records),
        "reason_macro_f1": round(macro_f1(expected_reasons, predicted_reasons), 4),
        "escalation_recall": round(tp / (tp + fn), 4) if tp + fn else 1.0,
        "false_escalation_rate": round(fp / max(sum(not e for e in expected_escalations), 1), 4),
        "pii_leaks": pii_leaks,
        "mean_confidence": round(sum(r["confidence"] for r in results) / len(results), 4),
        "reason_distribution": dict(Counter(predicted_reasons)),
    }
