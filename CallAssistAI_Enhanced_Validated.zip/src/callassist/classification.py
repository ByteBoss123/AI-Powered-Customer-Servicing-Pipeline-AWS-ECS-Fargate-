from __future__ import annotations

import re

from .models import Classification


REASON_KEYWORDS = {
    "payment_issue": {
        "payment",
        "paid",
        "autopay",
        "due",
        "late fee",
        "remittance",
        "scheduled transfer",
        "bill payment",
        "payment reversed",
        "balance did not update",
        "not posted",
    },
    "fraud_dispute": {
        "fraud",
        "fraudulent",
        "stolen",
        "not mine",
        "unauthorized",
        "dispute",
        "never authorized",
        "do not recognize",
        "unrecognized",
        "without permission",
        "unknown purchase",
        "merchant debit",
        "suspicious charge",
        "compromised",
    },
    "card_access": {
        "declined",
        "locked",
        "activate",
        "activation",
        "replacement",
        "plastic",
        "chip",
        "checkout",
        "automated teller",
        "tap",
        "pin",
        "expired card",
        "stopped working",
    },
    "account_information": {
        "address",
        "email",
        "phone",
        "profile",
        "contact information",
        "legal name",
        "mailing",
        "statements are mailed",
        "personal information",
    },
    "rewards": {
        "points",
        "miles",
        "reward",
        "cashback",
        "loyalty",
        "bonus",
        "redemption",
        "travel credit",
    },
}
NEGATIVE = {"angry", "frustrated", "upset", "terrible", "unacceptable", "hate", "worried"}
POSITIVE = {"thanks", "thank you", "great", "helpful", "appreciate", "resolved"}


class RuleClassifier:
    def classify(self, text: str) -> Classification:
        normalized = text.lower()
        scores = {
            label: sum(1 for word in words if word in normalized)
            for label, words in REASON_KEYWORDS.items()
        }
        reason, count = max(scores.items(), key=lambda item: item[1])
        if count == 0:
            reason, reason_confidence = "other", 0.35
        else:
            reason_confidence = min(0.98, 0.55 + 0.12 * count)
        neg = sum(1 for word in NEGATIVE if word in normalized)
        pos = sum(1 for word in POSITIVE if word in normalized)
        sentiment = "negative" if neg > pos else "positive" if pos > neg else "neutral"
        sentiment_confidence = min(0.95, 0.55 + 0.1 * abs(neg - pos))
        return Classification(reason, reason_confidence, sentiment, sentiment_confidence)


def extract_fields(text: str) -> dict[str, str]:
    fields: dict[str, str] = {}
    amount = re.search(r"\$\s?([0-9]+(?:\.[0-9]{1,2})?)", text)
    if amount:
        fields["amount"] = amount.group(1)
    merchant = re.search(
        r"(?:merchant|charge (?:from|at))\s+([A-Za-z0-9 &'_-]{2,40}?)"
        r"(?=\s+on\s+(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)|[.,;]|$)",
        text,
        re.I,
    )
    if merchant:
        fields["merchant"] = merchant.group(1).strip(" .,;")
    date = re.search(r"\b(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\s+\d{1,2}\b", text, re.I)
    if date:
        fields["date"] = date.group(0)
    return fields
