from __future__ import annotations

import json
import math
import re
from dataclasses import dataclass
from pathlib import Path

from .models import RetrievedPolicy


def _tokens(text: str) -> set[str]:
    return set(re.findall(r"[a-z0-9]+", text.lower()))


@dataclass
class PolicyDocument:
    policy_id: str
    title: str
    text: str


def load_policies(directory: Path) -> list[PolicyDocument]:
    documents: list[PolicyDocument] = []
    for path in sorted(directory.glob("*.json")):
        data = json.loads(path.read_text(encoding="utf-8"))
        documents.append(PolicyDocument(data["policy_id"], data["title"], data["text"]))
    if not documents:
        raise RuntimeError(f"No policy documents found in {directory}")
    return documents


class LocalPolicyRetriever:
    """Small deterministic BM25-style retriever suitable for local evaluation."""

    def __init__(self, documents: list[PolicyDocument]) -> None:
        self.documents = documents
        self.doc_tokens = [_tokens(f"{d.title} {d.text}") for d in documents]
        self.df: dict[str, int] = {}
        for tokens in self.doc_tokens:
            for token in tokens:
                self.df[token] = self.df.get(token, 0) + 1

    def retrieve(self, query: str, top_k: int = 3) -> list[RetrievedPolicy]:
        query_tokens = _tokens(query)
        n = len(self.documents)
        ranked: list[tuple[float, int]] = []
        for index, tokens in enumerate(self.doc_tokens):
            score = 0.0
            for token in query_tokens & tokens:
                score += math.log((n + 1) / (self.df.get(token, 0) + 0.5)) + 1.0
            ranked.append((score, index))
        ranked.sort(reverse=True)
        results = []
        for score, index in ranked[:top_k]:
            doc = self.documents[index]
            normalized = score / max(len(query_tokens), 1)
            results.append(RetrievedPolicy(doc.policy_id, doc.title, doc.text, min(normalized, 1.0)))
        return results


class LlamaIndexPolicyRetriever:
    """LlamaIndex adapter. Index construction is local and does not require a hosted LLM."""

    def __init__(self, documents: list[PolicyDocument], top_k: int = 3) -> None:
        try:
            from llama_index.core import Document, VectorStoreIndex
            from llama_index.embeddings.huggingface import HuggingFaceEmbedding
        except ImportError as exc:
            raise RuntimeError("Install callassist-ai[genai] to enable LlamaIndex") from exc
        nodes = [
            Document(text=d.text, metadata={"policy_id": d.policy_id, "title": d.title})
            for d in documents
        ]
        embedding = HuggingFaceEmbedding(model_name="sentence-transformers/all-MiniLM-L6-v2")
        self.retriever = VectorStoreIndex.from_documents(nodes, embed_model=embedding).as_retriever(
            similarity_top_k=top_k
        )

    def retrieve(self, query: str, top_k: int = 3) -> list[RetrievedPolicy]:
        output = []
        for item in self.retriever.retrieve(query)[:top_k]:
            metadata = item.node.metadata
            output.append(
                RetrievedPolicy(
                    metadata["policy_id"], metadata["title"], item.node.get_text(), float(item.score or 0)
                )
            )
        return output
