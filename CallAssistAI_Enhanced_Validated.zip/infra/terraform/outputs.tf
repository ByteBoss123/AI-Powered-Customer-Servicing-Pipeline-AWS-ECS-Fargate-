output "cluster_name" { value = aws_ecs_cluster.main.name }
output "service_name" { value = aws_ecs_service.api.name }
output "calls_bucket" { value = aws_s3_bucket.calls.id }
output "audit_table" { value = aws_dynamodb_table.audits.name }
output "load_balancer_dns" { value = aws_lb.api.dns_name }
