variable "aws_region" {
  type    = string
  default = "us-east-1"
}
variable "project_name" {
  type    = string
  default = "callassist-ai"
}
variable "container_image" { type = string }
variable "api_key_secret_arn" {
  type      = string
  sensitive = true
}
variable "vpc_id" { type = string }
variable "private_subnet_ids" { type = list(string) }
variable "load_balancer_subnet_ids" { type = list(string) }
variable "allowed_cidr_blocks" {
  type    = list(string)
  default = []
}
variable "internal_load_balancer" {
  type    = bool
  default = true
}
variable "desired_count" {
  type    = number
  default = 2
}
variable "min_tasks" {
  type    = number
  default = 2
}
variable "max_tasks" {
  type    = number
  default = 6
}
variable "task_cpu" {
  type    = number
  default = 2048
}
variable "task_memory" {
  type    = number
  default = 4096
}
variable "audio_retention_days" {
  type    = number
  default = 30
}
variable "provider_mode" {
  type    = string
  default = "local"
}
variable "model_version" {
  type    = string
  default = "local-v2"
}
variable "whisper_model" {
  type    = string
  default = "tiny.en"
}
variable "hf_model" {
  type    = string
  default = "google/flan-t5-small"
}
