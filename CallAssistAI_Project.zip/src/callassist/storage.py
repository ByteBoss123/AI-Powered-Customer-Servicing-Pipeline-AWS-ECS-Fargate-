from __future__ import annotations

import json
import sqlite3
from pathlib import Path
from typing import Any


class AuditStore:
    def __init__(self, path: Path) -> None:
        self.path = path
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._initialize()

    def _connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self.path)
        connection.row_factory = sqlite3.Row
        return connection

    def _initialize(self) -> None:
        with self._connect() as db:
            db.executescript(
                """
                CREATE TABLE IF NOT EXISTS call_audits (
                  call_id TEXT PRIMARY KEY,
                  created_at TEXT NOT NULL,
                  model_version TEXT NOT NULL,
                  escalated INTEGER NOT NULL,
                  confidence REAL NOT NULL,
                  result_json TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_audits_created ON call_audits(created_at);
                CREATE INDEX IF NOT EXISTS idx_audits_version ON call_audits(model_version);
                """
            )

    def save_result(self, result: dict[str, Any]) -> None:
        with self._connect() as db:
            db.execute(
                """INSERT OR REPLACE INTO call_audits
                (call_id, created_at, model_version, escalated, confidence, result_json)
                VALUES (?, ?, ?, ?, ?, ?)""",
                (
                    result["call_id"], result["created_at"], result["model_version"],
                    int(result["escalated"]), result["confidence"], json.dumps(result, sort_keys=True),
                ),
            )

    def get_result(self, call_id: str) -> dict[str, Any] | None:
        with self._connect() as db:
            row = db.execute("SELECT result_json FROM call_audits WHERE call_id = ?", (call_id,)).fetchone()
        return json.loads(row["result_json"]) if row else None

    def recent_results(self, limit: int = 100) -> list[dict[str, Any]]:
        with self._connect() as db:
            rows = db.execute(
                "SELECT result_json FROM call_audits ORDER BY created_at DESC LIMIT ?", (limit,)
            ).fetchall()
        return [json.loads(row["result_json"]) for row in rows]

