# CallAssist AI model card

## Intended use

Portfolio demonstration of an auditable customer-servicing workflow using synthetic transcripts. It is intended for engineering evaluation, not autonomous financial decisions or real customer servicing.

## Evaluation data

- 15 synthetic, manually labeled transcripts
- Six call-reason labels: fraud dispute, payment issue, card access, rewards, account information, and other
- Six cases requiring escalation
- Three seeded PII values used to test redaction
- No real customers, production traffic, accents, background noise, or demographic coverage

The dataset is intentionally small and easy. Results demonstrate test-harness behavior, not generalization.

## Verified local-provider results

| Metric | Baseline v1 (threshold 0.65) | Selected v2 (threshold 0.45) |
|---|---:|---:|
| Call-reason macro F1 | 1.0000 | 1.0000 |
| Escalation recall | 1.0000 | 1.0000 |
| False-escalation rate | 0.4444 | 0.0000 |
| Seeded PII leaks | 0 | 0 |
| Evaluation records | 15 | 15 |

The controlled threshold change reduced false escalations on this dataset while retaining escalation recall. It must be revalidated on a larger and more representative dataset before deployment.

## Components

- Deterministic keyword classifier and sentiment detector in local mode
- BM25-style local policy retrieval
- Deterministic grounded response template
- Optional Whisper, LlamaIndex, Hugging Face, LangGraph, and Weave integrations

Real-provider metrics are deliberately not reported because the heavyweight models were not executed in the verification environment.

## Risks and limitations

- Keyword rules are brittle to paraphrases, multilingual calls, sarcasm, and domain shift.
- Regex PII detection can miss novel formats and produce false positives.
- The retrieval corpus contains only four short synthetic policies.
- The audio adapter needs evaluation for word error rate, accents, noise, and diarization.
- Threshold tuning on the same small golden set can overfit.
- A human must review fraud, identity changes, unsupported intents, and low-confidence cases.

## Required next validation

1. Expand to at least 100 diverse held-out transcripts and 20–40 licensed or synthetic audio calls.
2. Measure transcription word error rate by audio condition.
3. Evaluate retrieval precision/recall and policy-grounded faithfulness.
4. Run fairness slices and PII recall testing.
5. Load-test the deployed API and report measured P50/P95 latency, throughput, and error rate.
6. Conduct security review, threat modeling, and retention-policy validation.

