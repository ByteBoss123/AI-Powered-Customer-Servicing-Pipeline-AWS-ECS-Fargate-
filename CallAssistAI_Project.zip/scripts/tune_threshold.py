from __future__ import annotations

import json
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from callassist.config import Settings
from callassist.evaluation import evaluate
from callassist.registry import ModelRegistry
from callassist.service import CallAssistService


def main() -> None:
    candidates = [0.45, 0.50, 0.55, 0.60, 0.65, 0.70]
    rows = []
    with tempfile.TemporaryDirectory() as directory:
        for threshold in candidates:
            settings = Settings(
                database_path=Path(directory) / f"eval-{threshold}.db",
                policy_dir=ROOT / "data" / "policies",
                confidence_threshold=threshold,
                model_version=f"local-threshold-{threshold:.2f}",
            )
            metrics = evaluate(
                CallAssistService(settings), ROOT / "data" / "evaluation" / "calls.json"
            )
            metrics["threshold"] = threshold
            metrics["objective"] = round(
                metrics["escalation_recall"] - metrics["false_escalation_rate"], 4
            )
            rows.append(metrics)
    eligible = [
        row for row in rows if row["escalation_recall"] >= 0.95 and row["pii_leaks"] == 0
    ]
    best = max(eligible, key=lambda row: (row["objective"], row["mean_confidence"]))
    artifact_dir = ROOT / "artifacts"
    artifact_dir.mkdir(exist_ok=True)
    output = {"candidates": rows, "selected": best}
    (artifact_dir / "threshold_tuning.json").write_text(
        json.dumps(output, indent=2) + "\n", encoding="utf-8"
    )

    registry = ModelRegistry(artifact_dir / "model_registry.db")
    baseline = next(row for row in rows if row["threshold"] == 0.65)
    registry.register("local-v1", {"confidence_threshold": 0.65}, baseline)
    registry.activate("local-v1")
    registry.register("local-v2", {"confidence_threshold": best["threshold"]}, best)
    registry.activate("local-v2")
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()
