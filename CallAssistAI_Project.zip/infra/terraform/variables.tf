variable "aws_region" { type = string, default = "us-east-1" }
variable "project_name" { type = string, default = "callassist-ai" }
variable "container_image" { type = string }
variable "api_key_secret_arn" { type = string, sensitive = true }
variable "vpc_id" { type = string }
variable "private_subnet_ids" { type = list(string) }
variable "desired_count" { type = number, default = 2 }

