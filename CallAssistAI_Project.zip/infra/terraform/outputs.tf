output "cluster_name" { value = aws_ecs_cluster.main.name }
output "service_name" { value = aws_ecs_service.api.name }
output "calls_bucket" { value = aws_s3_bucket.calls.id }

