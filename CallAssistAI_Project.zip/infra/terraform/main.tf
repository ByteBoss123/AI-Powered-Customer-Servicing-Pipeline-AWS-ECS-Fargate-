data "aws_vpc" "selected" { id = var.vpc_id }

resource "aws_s3_bucket" "calls" {
  bucket_prefix = "${var.project_name}-calls-"
}

resource "aws_s3_bucket_server_side_encryption_configuration" "calls" {
  bucket = aws_s3_bucket.calls.id
  rule { apply_server_side_encryption_by_default { sse_algorithm = "AES256" } }
}

resource "aws_s3_bucket_public_access_block" "calls" {
  bucket = aws_s3_bucket.calls.id
  block_public_acls = true
  block_public_policy = true
  ignore_public_acls = true
  restrict_public_buckets = true
}

resource "aws_cloudwatch_log_group" "api" {
  name = "/ecs/${var.project_name}"
  retention_in_days = 30
}

resource "aws_ecs_cluster" "main" { name = var.project_name }

resource "aws_iam_role" "execution" {
  name_prefix = "${var.project_name}-exec-"
  assume_role_policy = jsonencode({
    Version = "2012-10-17", Statement = [{
      Effect = "Allow", Principal = { Service = "ecs-tasks.amazonaws.com" }, Action = "sts:AssumeRole"
    }]
  })
}

resource "aws_iam_role_policy_attachment" "execution" {
  role = aws_iam_role.execution.name
  policy_arn = "arn:aws:iam::aws:policy/service-role/AmazonECSTaskExecutionRolePolicy"
}

resource "aws_iam_role" "task" {
  name_prefix = "${var.project_name}-task-"
  assume_role_policy = aws_iam_role.execution.assume_role_policy
}

resource "aws_iam_role_policy" "task" {
  role = aws_iam_role.task.id
  policy = jsonencode({
    Version = "2012-10-17", Statement = [{
      Effect = "Allow", Action = ["s3:GetObject", "s3:PutObject"], Resource = "${aws_s3_bucket.calls.arn}/*"
    }]
  })
}

resource "aws_security_group" "api" {
  name_prefix = "${var.project_name}-"
  vpc_id = var.vpc_id
  ingress { from_port = 8000, to_port = 8000, protocol = "tcp", cidr_blocks = [data.aws_vpc.selected.cidr_block] }
  egress { from_port = 0, to_port = 0, protocol = "-1", cidr_blocks = ["0.0.0.0/0"] }
}

resource "aws_ecs_task_definition" "api" {
  family = var.project_name
  requires_compatibilities = ["FARGATE"]
  network_mode = "awsvpc"
  cpu = 1024
  memory = 2048
  execution_role_arn = aws_iam_role.execution.arn
  task_role_arn = aws_iam_role.task.arn
  container_definitions = jsonencode([{
    name = "api", image = var.container_image, essential = true,
    portMappings = [{ containerPort = 8000, protocol = "tcp" }],
    environment = [
      { name = "CALLASSIST_ENV", value = "production" },
      { name = "S3_BUCKET", value = aws_s3_bucket.calls.id }
    ],
    secrets = [{ name = "CALLASSIST_API_KEY", valueFrom = var.api_key_secret_arn }],
    logConfiguration = {
      logDriver = "awslogs",
      options = { awslogs-group = aws_cloudwatch_log_group.api.name, awslogs-region = var.aws_region, awslogs-stream-prefix = "api" }
    }
  }])
}

resource "aws_ecs_service" "api" {
  name = var.project_name
  cluster = aws_ecs_cluster.main.id
  task_definition = aws_ecs_task_definition.api.arn
  desired_count = var.desired_count
  launch_type = "FARGATE"
  network_configuration {
    subnets = var.private_subnet_ids
    security_groups = [aws_security_group.api.id]
    assign_public_ip = false
  }
  deployment_minimum_healthy_percent = 100
  deployment_maximum_percent = 200
}

resource "aws_cloudwatch_metric_alarm" "task_count" {
  alarm_name = "${var.project_name}-no-running-tasks"
  comparison_operator = "LessThanThreshold"
  evaluation_periods = 2
  metric_name = "RunningTaskCount"
  namespace = "ECS/ContainerInsights"
  period = 60
  statistic = "Minimum"
  threshold = 1
  alarm_description = "CallAssist has no running ECS tasks"
  dimensions = { ClusterName = aws_ecs_cluster.main.name, ServiceName = aws_ecs_service.api.name }
}

